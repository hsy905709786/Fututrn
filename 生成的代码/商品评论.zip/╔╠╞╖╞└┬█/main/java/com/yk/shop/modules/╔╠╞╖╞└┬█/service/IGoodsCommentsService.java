/**
 * 
 */
package com.yk.shop.modules.商品评论.service;

import java.util.List;

import com.yk.shop.baseentity.Page;
import com.yk.shop.modules.商品评论.entity.GoodsComments;


/**
 * 商品点赞Service
 * @author huangshouyong
 * @version 2018-05-08
 */
public interface IGoodsCommentsService extends IBaseService<GoodsComments> {
	
}