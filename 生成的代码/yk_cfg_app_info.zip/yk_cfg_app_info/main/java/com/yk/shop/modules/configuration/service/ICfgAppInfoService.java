/**
 * 
 */
package com.yk.shop.modules.configuration.service;

import java.util.List;

import com.yk.shop.baseentity.Page;
import com.yk.shop.modules.configuration.entity.CfgAppInfo;


/**
 * infoService
 * @author 黄寿勇
 * @version 2018-05-17
 */
public interface ICfgAppInfoService extends IBaseService<CfgAppInfo> {
	
}