/**
 * 
 */
package com.yk.shop.modules.message.service;

import java.util.List;

import com.yk.shop.baseentity.Page;
import com.yk.shop.modules.message.entity.MessageBase;


/**
 * 消息Service
 * @author 黄寿勇
 * @version 2018-05-17
 */
public interface IMessageBaseService extends IBaseService<MessageBase> {
	
}